/*
Creating the connection and dropping the original procedure to allow
rerunning of the code
*/

USE AP
GO

DROP PROCEDURE IF EXISTS sp_GetInvoiceData
GO

/*

Creating the procedure for the SSRS. Default value is set to NULL
and the WHERE clause allows the statement to accept a valid number
or a NULL from the default.

*/

CREATE PROCEDURE sp_GetInvoiceData

@TermsID INT = NULL

AS 

BEGIN

	SET NOCOUNT ON;

	SELECT * 
	FROM Invoices
	WHERE @TermsID IS NULL OR TermsID = @TermsID

END